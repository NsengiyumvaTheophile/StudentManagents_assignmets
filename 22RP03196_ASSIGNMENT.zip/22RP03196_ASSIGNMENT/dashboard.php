<?php
include 'session.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
 

</style>
<body>
    <div class="container">
        <h1>Welcome to the Student Management System</h1>
        <nav>
            <ul>
                <li><a href="add_student.php">Add Student</a></li>
                <li><a href="view_students.php">View Students</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>
